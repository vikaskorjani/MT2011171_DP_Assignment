package utils;

public class RunTimeSetting {
	
	 public static String dbUser="root"; 
	 public static String dbPwd="root";
	 public static String dbName="wizard";
	 public static String url="jdbc:mysql://localhost/";
	 
	 
}
